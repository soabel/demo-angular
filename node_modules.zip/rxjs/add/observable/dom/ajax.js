"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
require("rxjs-compat/add/observable/dom/ajax");
//# sourceMappingURL=ajax.js.map