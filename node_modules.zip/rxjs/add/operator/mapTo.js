"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
require("rxjs-compat/add/operator/mapTo");
//# sourceMappingURL=mapTo.js.map