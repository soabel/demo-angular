import { Observable } from '../Observable';
export declare function scalar<T>(value: T): Observable<T>;
